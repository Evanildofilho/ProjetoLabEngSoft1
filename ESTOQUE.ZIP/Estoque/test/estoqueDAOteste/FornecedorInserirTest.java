/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estoqueDAOteste;

import beans.Fornecedor;
import beans.Funcionario;
import estoqueDAO.FornecedorDAO;
import java.util.List;
import org.junit.Test;


/**
 *
 * @author evani
 */
public class FornecedorInserirTest {
    
    public FornecedorInserirTest() {
    }
    
 
   
   
   
    @Test
    public void testInserir() {
        
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setCnpj("1234567891234");
        Funcionario funcionario = new Funcionario();
        funcionario.setId_funcionario(1);
        fornecedor.setFk_id_funcionario(funcionario);
        fornecedor.setNomeFantasia("são braz");
        fornecedor.setTelefone("(83) 99524-8844");
        fornecedor.setEmail("email@gmail.com");
        
        FornecedorDAO Fornecedordao = new FornecedorDAO();
        Fornecedordao.inserirFornecedor(fornecedor);
    }
    
}
