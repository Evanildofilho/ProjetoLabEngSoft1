/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estoqueDAOteste;

import beans.Fornecedor;
import beans.Funcionario;
import estoqueDAO.FornecedorDAO;
import org.junit.Test;

/**
 *
 * @author evani
 */
public class FornecedorEditarTest {
    
    @Test
    public void testEditar() {
        
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setCnpj("1234567891234");
        Funcionario funcionario = new Funcionario();
        funcionario.setId_funcionario(1);
        fornecedor.setFk_id_funcionario(funcionario);
        fornecedor.setNomeFantasia("são braz");
        fornecedor.setTelefone("(83) 99524-8844");
        fornecedor.setEmail("editado");
        FornecedorDAO Fornecedordao = new FornecedorDAO();
        Fornecedordao.editar(fornecedor);
    }
    
    
}
